import React from 'react'
import { connect } from 'react-redux'

export const contactrequest = (props) => {
  return (
    <div>contactrequest</div>
  )
}

const mapStateToProps = (state) => ({})

const mapDispatchToProps = {}

export default connect(mapStateToProps, mapDispatchToProps)(contactrequest)