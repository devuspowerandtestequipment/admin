import React from 'react'

export default function ComponentToPrint() {
  return (
    <div>
        <p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
<p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
<p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
<p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
<p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
<p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
<p>From the code above, we imported the ReactToPrint library, then we called the ReactToPrint component in the body. The ReactToPrint holds the trigger (this can be a button or what so ever we choose) and the content (this is a reference to the component that is to be printed).

Below the ReactToPrint component is the component to be printed wit</p>
    </div>
  )
}
