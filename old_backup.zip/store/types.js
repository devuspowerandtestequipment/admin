export const GET_POSTS = 'GET_POSTS';

export const AUTH_USER_INFORMATION = 'ecomesite888xxauthuserinfo';
export const ADMIN_SETTINGS = 'ecomesite888xxadminsettingsinfo';


